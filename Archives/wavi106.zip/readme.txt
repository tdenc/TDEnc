WAVI v1.06 and SILENCE v1.04 - (c) 2007 Tamas Kurucsai
Licensed under the terms of the GNU General Public License

Homepage: http://sourceforge.net/projects/wavi-avi2wav

Start the .exe files without any parameters to get some help.

Changelog:

2007.08.16:
WAVI v1.06: option to write extended WAV header with channel mask (thanks to tebasuna51)

2007.08.06:
WAVI v1.05: optimized performance

2007.06.26:
WAVI v1.04: added support for floating-point samples (thanks to tebasuna51)
SILENCE v1.04: added support for floating-point samples (thanks to tebasuna51)
SILENCE v1.04: added support fot files > 4G; use Win32 API

2007.06.24:
WAVI + SILENCE v1.03: fixed size field in data chunk header (thanks to tebasuna51)
WAVI v1.03: don't expect that AVIStreamRead stops at the end of the stream (thanks to tebasuna51)
SILENCE v1.03: removed annoying debug message
